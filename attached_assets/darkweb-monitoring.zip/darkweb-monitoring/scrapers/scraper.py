
import logging
import re
import smtplib
from email.message import EmailMessage
import random
from unittest import result
from tabulate import tabulate
import os
import sys
import csv
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
import nltk
from bs4 import BeautifulSoup
import schedule
import requests
import time
from typing import List, Dict
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, quote_plus

# linking database
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'database')))
from db_manager import detect_threats, insert_data


# scraper.py link to json file
from categories import load_categories, match_personal_data


# --- Set NLTK to look in local data folder only ---
nltk_data_path = os.path.expanduser("C:/Users/walee/nltk_data")
nltk.data.path.append(nltk_data_path)

# --- Check if required resources are present ---
try:
    nltk.data.find("tokenizers/punkt")
    nltk.data.find("corpora/wordnet")
except LookupError as e:
    print("Missing required NLTK data locally:", e)
    exit(1)

# List of data leak hosting or forum sites
TARGET_SITES = [
    'pastebin.com', 'pastie.io', 'controlc.com', 'justpaste.it', 'dpaste.com',
    'breachforums.is', 'cracked.to', 'nulled.to', 'sinister.ly',
    '4chan.org', 'reddit.com', 'github.com', 'gitlab.com',
    'mega.nz', 'gofile.io', 'pixeldrain.com', 'bayfiles.com',
    'wetransfer.com', 'haveibeenpwned.com'
]

# Regular expressions for scraping data
EMAIL_REGEX = r'[\w.-]+@[\w.-]+\.\w+'
URL_REGEX = r'http(s)?://\S+'
FILE_REGEX = r'\.(zip|rar|txt|pdf|docx|exe)'


# ---- Initialize Lemmatizer ----
lemmatizer = WordNetLemmatizer()

# ---- Email Configuration ----
EMAIL_SENDER = "aliciaalarcon777@gmail.com"
EMAIL_PASSWORD = "avzx wcyw cuzi yaiv"

# ---- Logging Setup ----
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

#

def search_duckduckgo(query: str) -> str:
    """Search DuckDuckGo directly using requests."""
    url = f"https://duckduckgo.com/html/?q={query}"
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}

    try:
        response = requests.get(url, headers=headers, timeout=5)  # Timeout after 5 seconds
        response.raise_for_status()  # Raise exception for HTTP errors
        if not response.text:
            print("[ERROR] No content returned from DuckDuckGo.")
            return None
        return response.text  # Return the raw HTML if request is successful
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] An error occurred while searching DuckDuckGo: {e}")
        return None

#

def make_request_with_retry(url, headers=None, retries=5, delay=5):
    """Makes a request with retry logic for rate-limiting errors (HTTP 429) or other timeouts."""
    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, timeout=5)  # Timeout after 5 seconds
            response.raise_for_status()  # Raise exception for HTTP errors
            return response.text  # Return the raw HTML if request is successful
        except requests.exceptions.RequestException as e:
            if response and response.status_code == 429:
                print(f"[INFO] Rate limit hit, retrying in {delay} seconds...")
                time.sleep(delay)  # Exponential backoff
                delay *= 2  # Double the delay each retry
            else:
                print(f"[ERROR] An error occurred: {e}")
                break  # Stop retries if a non-retryable error occurs
    return None  # Return None if max retries reached without success


# Function to search for keywords on clear web 

def search_keywords_on_clear_web(sites, keywords):
    all_results = []
    for site in sites:
        for keyword in keywords:
            query = f"site:{site} {keyword}"
            html = search_duckduckgo(query)
            results = analyze_search_results(html)  # Make sure this returns a list
            all_results.extend(results)
    return all_results

#

def scrape_page(url):
    """ Scrapes emails, URLs, images, and files from the given URL """
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    # Find emails using regex
    emails = re.findall(EMAIL_REGEX, soup.get_text())

    # Find URLs using regex
    urls = re.findall(URL_REGEX, soup.get_text())

    # Find image links from <img> tags
    images = [img['src'] for img in soup.find_all('img', src=True)]

    # Find file links based on the file extension regex
    files = re.findall(FILE_REGEX, soup.get_text())

    # Extract a snippet of the text for readability (truncate to 500 chars)
    text_snippet = soup.get_text()[:500]

    # Create a structured data object
    data = {
        'url': url,
        'emails': emails,
        'urls': urls,
        'images': images,
        'files': files,
        'text_snippet': text_snippet
    }

    return data


# ---- Keyword Categories ----
keyword_categories = {
    'credentials': ['password', 'username', 'login', 'credentials', 'auth'],
    'personal_info': ['name', 'email', 'phone', 'address', 'dob', 'ssn'],
    'financial_info': ['credit card', 'bank account', 'routing number'],
    'cyber_terms': ['malware', 'exploit', 'ransomware', 'phishing', 'ddos'],
    'darkweb': ['onion', 'tor', '.onion', 'darkweb'],
    'sensitive_data': ['leak', 'dump', 'exposed', 'breach', 'database'],
}

# ---- Tokenization and Lemmatization ----
def tokenize_and_lemmatize(text):
    tokens = word_tokenize(text.lower())
    return [lemmatizer.lemmatize(token) for token in tokens]

# ---- User-Agent Randomization ----
def get_random_headers():
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "Mozilla/5.0 (X11; Linux x86_64)",
    ]
    return {"User-Agent": random.choice(user_agents)}

# ---- Display Results in Table ----
def display_links(links):
    if not links:
        print("No relevant links found.")
        return
    table = []
    for text, url, keywords, categories, score in links:
        table.append([text[:80], url, ', '.join(keywords), ', '.join(categories), score])
    print(tabulate(table, headers=["Text", "URL", "Keywords", "Categories", "Score"]))

# ---- Save Results to CSV ----

def save_to_csv(data, filename):
    if not data:
        print("No data to save.")
        return
    with open(filename, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(data)

# ---- DuckDuckGo Search ----


# p.s func
def search_site(site: str, term: str) -> List[Dict]:
    query = f"site:{site} {term}"
    html = search_duckduckgo(query)
    if not html:
        return []

    print("[DEBUG] Raw HTML from DuckDuckGo:")
    print(html[:500])  # Print the first 500 characters of the HTML for inspection

    soup = BeautifulSoup(html, 'html.parser')

    results = []
    no_results_msg = "No results found"  # Handle no results gracefully
    if no_results_msg in soup.get_text():
        print("[INFO] No results found in the HTML response.")
        return []

    for result in soup.find_all('a', {'class': 'result__a'}):  # Adjust the class if necessary
        title = result.get_text(strip=True)
        url = result['href']
        snippet_tag = result.find_next('a', {'class': 'result__snippet'})

        snippet = snippet_tag.get_text(strip=True) if snippet_tag else ''
        results.append({
            'title': title,
            'url': url,
            'snippet': snippet
        })

    return results


    # DuckDuckGo results parsing (the structure might be different from Google)
    for result in soup.find_all('a', {'class': 'result__a'}):
        title = result.get_text(strip=True)
        url = result['href']
        snippet_tag = result.find_next('a', {'class': 'result__snippet'})

        snippet = snippet_tag.get_text(strip=True) if snippet_tag else ''

        results.append({
            'title': title,
            'url': url,
            'snippet': snippet
        })

    return results


# Parallel search function with retry logic

def run_parallel_searches(search_term: str, sites: List[str]) -> List[Dict]:
    results = []
    with ThreadPoolExecutor(max_workers=len(sites)) as executor:
        futures = [executor.submit(search_site, site, search_term) for site in sites]
        for future in futures:
            try:
                result = future.result()
                if result:  # Only append results if found
                    results.extend(result)
                else:
                    print(f"[INFO] No results found for search term: {search_term}")
            except Exception as e:
                print(f"[ERROR] Error during search: {str(e)}")
    return results


# ---- Crawl and Analyze Results ----
def analyze_search_results(results: List[Dict], search_terms: List[str], user_name: str, user_email: str):
    final_links = []

    for result in results:
        title = result.get('title', '')
        url = result.get('url', '')
        snippet_text = result.get('snippet', '')

        full_text = f"{title} {snippet_text}".lower()

        match_terms = [term for term in search_terms if term.lower() in full_text]
        found_keywords, categories, score = analyze_threat(full_text)

        if match_terms or found_keywords:
            total_score = score + len(match_terms)
            final_links.append((title[:80], url, match_terms + found_keywords, categories, total_score))

            if total_score > 3:
                send_alert(
                    f"[ALERT] Potential Threat Detected on {url}",
                    f"Text: {title}\nSnippet: {snippet_text}\nURL: {url}\nTerms: {', '.join(match_terms + found_keywords)}\nCategories: {', '.join(categories)}\nScore: {total_score}",
                    user_email
                )

    display_links(final_links)

    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    csv_data = [
        [timestamp, title, url, ', '.join(kws), ', '.join(cats), score, user_name, user_email]
        for title, url, kws, cats, score in final_links
    ]
    save_to_csv(csv_data)

# to parse search resukts to find snippets we need

def parse_search_results(html):
    # Ensure the HTML is properly decoded in case of encoding issues
    if isinstance(html, bytes):
        html = html.decode('utf-8', 'ignore')  # Try decoding the response if it's in bytes
    # Now parse the HTML using BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    
    results = []
    
    # Assuming you're extracting titles, URLs, and snippets from the search results
    for result in soup.find_all('div', class_='result'):
        title = result.find('h2').get_text() if result.find('h2') else None
        url = result.find('a')['href'] if result.find('a') else None
        snippet = result.find('p').get_text() if result.find('p') else None
        results.append({'title': title, 'url': url, 'snippet': snippet})
    
    return results


# 
from db_manager import detect_threats, insert_data

# Assuming `results` is a list of dicts from your parse_search_results or scrape_page
threats = detect_threats(result)
insert_data(threats)




# ---- Threat Analysis ----

def analyze_threat(text: str) -> (List[str], List[str], int): # type: ignore
    tokens = tokenize_and_lemmatize(text)
    found_keywords = []
    categories = []
    score = 0

    for category, keywords in keyword_categories.items():
        for keyword in keywords:
            keyword_tokens = tokenize_and_lemmatize(keyword)
            if all(kw in tokens for kw in keyword_tokens):
                found_keywords.append(keyword)
                categories.append(category)
                score += 1

    return found_keywords, list(set(categories)), score


# ---- Email Alert Function ----

def send_alert(subject, body, to_email):
    msg = EmailMessage()
    msg.set_content(body)
    msg["Subject"] = subject
    msg["From"] = EMAIL_SENDER
    msg["To"] = to_email

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(EMAIL_SENDER, EMAIL_PASSWORD)
            smtp.send_message(msg)
        print(f"[+] Alert sent to {to_email}")
    except Exception as e:
        print(f"[!] Failed to send alert to {to_email}: {e}")
        # Optional: uncomment to debug
        # print(f"Subject: {subject}")
        # print(f"Body: {body}")


# ---- Ask User for Keywords and Perform Search ----
def get_user_input():
    print("Available Categories:")
    for category in keyword_categories:
        print(f"- {category}")
    
    # Asking for keywords to search. The input is comma-separated.
    user_input = input("\nEnter keywords to search (comma-separated): ")
    
    # Clean and split the input to ensure no extra spaces and store as a list of terms
    search_terms = [term.strip().lower() for term in user_input.split(',') if term.strip()]
    
    if not search_terms:
        print("No valid keywords entered. Please enter at least one keyword.")
        return get_user_input()  # Recursive call to ask again if no keywords
    
    return search_terms

# ---- Ask User for Name and Email ----
def get_user_details():
    name = input("Enter your name: ")
    email = input("Enter your email address: ")
    return name, email

# ---- Job Function for Scheduler ----
def job(user_name, user_email, search_terms):
    print(f"Starting search for the following terms: {', '.join(search_terms)}")

    # Search for the keywords on the listed sites
    results = run_parallel_searches(search_terms[0], TARGET_SITES)  # Assuming you are searching for one keyword at a time

    # Analyze and process the results for the current search terms
    analyze_search_results(results, search_terms, user_name, user_email)

    print(f"Search for '{', '.join(search_terms)}' completed.")




# Get user details once
user_name, user_email = get_user_details()
search_terms = get_user_input()


# Schedule the job
schedule.every(6).hours.do(lambda: job(user_name, user_email, search_terms))



# Test URL
test_url = "https://example.com"  # Replace with a real URL

scraped_data = scrape_page(test_url)

# Save raw post
insert_data(scraped_data)  # Stores into 'posts' table

# Check for threat keywords
keywords = ['hacking', 'malware', 'exploit', 'password']
detected_keywords = [k for k in keywords if k in scraped_data['text_snippet'].lower()]
if detected_keywords:
    scraped_data['detected_keywords'] = ','.join(detected_keywords)
    detect_threats(scraped_data)  # Stores into 'threats' table



def main():
    user_name = input("Enter your name: ")
    user_email = input("Enter your email: ")
    search_terms_input = input("Enter keywords to search (comma-separated): ")
    search_terms = [term.strip() for term in search_terms_input.split(",") if term.strip()]

    TARGET_SITES = ["https://duckduckgo.com"]

    print("\n[•] Running parallel threat intelligence search...\n")

    raw_results = run_parallel_searches(" ".join(search_terms), TARGET_SITES)
    
    # Debugging: Check if raw_results is empty or not
    print(f"[DEBUG] raw_results: {raw_results}")

    if raw_results:
        for result_html in raw_results:
            print(f"[DEBUG] result_html: {result_html}")
            if result_html:
                parsed_results = parse_search_results(result_html)  # Ensure this returns a list of dicts
                print(f"[DEBUG] parsed_results: {parsed_results}")
                analyze_search_results(parsed_results, search_terms, user_name, user_email)
    else:
        print("[DEBUG] No results found!")

    
if __name__ == "__main__":
    main()




