import requests
import json

import os
print("Current working directory:", os.getcwd())


# Load categories and additional info from JSON file

def load_categories():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    file_path = os.path.join(base_dir, 'categories.json')
    
    try:
        with open(file_path, 'r') as f:
            categories = json.load(f)
        return categories
    except Exception as e:
        print(f"Error loading categories: {e}")
        return {}


# Collect user profile data (name, email, phone)
def get_user_profile():
    print("Enter your name:")
    name = input()
    print("Enter your email address:")
    email = input()
    print("Enter your phone number:")
    phone = input()
    
    return {"name": name, "email": email, "phone": phone}

# Function to generate search terms based on profile data and categories
def generate_search_terms(profile, categories, additional_info):
    search_terms = set()
    
    # Automatically add personal information to the search terms
    if profile["email"]:
        search_terms.add(profile["email"])
    
    if profile["phone"]:
        search_terms.add(profile["phone"])
    
    # Match profile data with relevant categories
    for category, keywords in categories.items():
        if category == "emails" and profile["email"]:
            search_terms.update(keywords)
        elif category == "personal_info" and (profile["name"] or profile["phone"]):
            search_terms.update(keywords)

    # Include additional keywords from the "additional_info" section
    for category, keywords in additional_info.items():
        if category == "emails" and profile["email"]:
            search_terms.update(keywords)
        elif category == "financial_info" and profile["phone"]:
            search_terms.update(keywords)

    return search_terms

# Example search using the generated search terms
def search_with_terms(search_terms):
    search_query = " ".join(search_terms)
    print(f"Searching for: {search_query}")
    
    # Simulate performing a search (replace with actual API call)
    search_results = perform_search(search_query)  
    return search_results

# Simulate a search API call (replace with actual API)
def perform_search(query):
    print(f"Performing search with query: {query}")
    # Simulate a mock result for now
    return {"results": [{"title": "Example Search Result", "link": "http://example.com"}]}

# Function to automatically match personal data (name, email, etc.)
def match_personal_data(profile_data, search_keywords):
    matched_keywords = []
    
    for keyword in search_keywords:
        if any(value.lower() in keyword.lower() for value in profile_data.values()):
            matched_keywords.append(keyword)
    
    return matched_keywords

# Main function to tie everything together
def main():
    # Load categories and additional_info from the external JSON file
    categories, additional_info = load_categories()
    
    # Get user profile data
    profile = get_user_profile()
    
    # Generate search terms based on profile and categories
    search_terms = generate_search_terms(profile, categories, additional_info)
    
    # Perform search using the generated search terms
    results = search_with_terms(search_terms)
    print(f"Search results: {results}")

# Run the main function
if __name__ == "__main__":
    main()
