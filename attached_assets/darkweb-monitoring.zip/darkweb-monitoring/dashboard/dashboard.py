from dash import Dash, dcc, html, Input, Output
import pandas as pd
import psycopg2
import dash_bootstrap_components as dbc
from flask import Flask, jsonify

app = Flask(__name__)


# Connect to PostgreSQL and fetch data
def fetch_posts():
    try:
        conn = psycopg2.connect(
            dbname="emp",
            user="postgres",
            password="pgadmin4",
            host="localhost",
            port="5432"
        )
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, snippet, text_snippet, timestamp FROM posts ORDER BY timestamp DESC")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        # If data exists, convert to DataFrame
        if rows:
            df = pd.DataFrame(rows, columns=["ID", "Title", "Snippet", "Text Snippet", "Timestamp"])
            return df
        else:
            return pd.DataFrame(columns=["ID", "Title", "Snippet", "Text Snippet", "Timestamp"])
    except Exception as e:
        print("❌ Error connecting to database:", e)
        return pd.DataFrame(columns=["ID", "Title", "Snippet", "Text Snippet", "Timestamp"])


# API endpoint to fetch posts
@app.route('/api/posts', methods=['GET'])
def get_posts():
    posts_df = fetch_posts()
    posts_json = posts_df.to_dict(orient="records")
    return jsonify(posts_json)


# Dash app
app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Dark Web Monitoring Dashboard"

app.layout = dbc.Container([
    html.H1("Dark Web Monitoring Dashboard", className="mt-4 mb-4"),

    dbc.Button("Refresh Data", id="refresh-btn", color="primary", className="mb-3"),

    html.Div(id="posts-container")
], fluid=True)

# Callback to refresh data
@app.callback(
    Output("posts-container", "children"),
    Input("refresh-btn", "n_clicks")
)
def update_posts(n):
    posts_df = fetch_posts()
    
    if posts_df.empty:
        return dbc.Alert("No data found or failed to fetch data.", color="warning")

    cards = []
    for _, post in posts_df.iterrows():
        cards.append(
            dbc.Card([
                dbc.CardHeader(html.H5(post["Title"])),
                dbc.CardBody([
                    html.P(post["Snippet"], className="card-text"),
                    html.P(post["Text Snippet"], className="card-text text-muted"),
                    html.Small(f"Posted on: {post['Timestamp']}", className="text-muted")
                ])
            ], className="mb-3")
        )
    return cards

if __name__ == "__main__":
    app.run_server(debug=True, port=5000)
