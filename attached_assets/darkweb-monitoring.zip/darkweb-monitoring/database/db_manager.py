# db_manager.py

import psycopg2

# Keywords to detect in the text snippet or snippet
keywords = ['hacking', 'malware', 'exploit', 'password', 'ransomware', 'breach', 'credentials']

def detect_threats(scraped_data_list):
    detected = []
    for post in scraped_data_list:
        content = post.get('text_snippet', '').lower() + ' ' + post.get('snippet', '').lower()
        found = [k for k in keywords if k in content]
        if found:
            post['detected_keywords'] = ','.join(found)
            detected.append(post)
    return detected

def insert_data(scraped_data_list):
    conn = psycopg2.connect(
        dbname="emp",
        user="postgres",      #
        password="pgadmin4",  #
        host="localhost",
        port="5432"
    )
    cursor = conn.cursor()

    for post in scraped_data_list:
        cursor.execute("""
            INSERT INTO posts (title, url, snippet, emails, urls, images, files, text_snippet)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (
            post.get('title'),
            post.get('url'),
            post.get('snippet'),
            ','.join(post.get('emails', [])),
            ','.join(post.get('urls', [])),
            ','.join(post.get('images', [])),
            ','.join(post.get('files', [])),
            post.get('text_snippet')
        ))

        post_id = cursor.fetchone()[0]

        if 'detected_keywords' in post:
            cursor.execute("""
                INSERT INTO threats (post_id, detected_keywords)
                VALUES (%s, %s)
            """, (post_id, post['detected_keywords']))

    conn.commit()
    cursor.close()
    conn.close()
